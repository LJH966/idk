function t(a,e){return{description:"Coolest cat on Solana.",favicon:"https://framerusercontent.com/assets/sTPsE7yoCvNZsJ4xLFu3pmv6j8.jpeg",socialImage:"https://framerusercontent.com/assets/4TNf4HWn6JfEsXSeQ3UfT28OJCs.png",title:"$HIPCAT on Solana"}}export{t as a};
//# sourceMappingURL=chunk-EVUJXSYR.mjs.map
